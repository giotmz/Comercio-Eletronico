<?php

namespace App\Http\Middleware;

use Closure;
use Firebase\JWT\{
    JWT, Key
};
use Illuminate\Http\Request;
use stdClass;

class CheckBearerToken
{
    public function handle(Request $request, Closure $next)
    {
        $token = $request->bearerToken();

        if (!$token) {
            return response()->json(['error' => 'Token Bearer ausente'], 401);
        }

        try {
            $options = new \stdClass();
            // $options->algorithm = ['HS256'];
            $secret_key = env('JWT_SECRET');
            $decoded = JWT::decode($token, new Key($secret_key, 'HS256'));
        } catch (\Exception $e) {
            return response()->json(['error' => 'Token inválido'], 401);
        }

        return $next($request);
    }
}

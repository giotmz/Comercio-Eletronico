<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;

use Illuminate\Http\{
    JsonResponse, Request,
    Response
};
use App\Models\Product;

class ProductController extends Controller
{
    public function index() : JsonResponse
    {
        return response()->json(Product::all());
    }

    public function store(Request $request) : JsonResponse | Response
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'description' => 'required|string',
            'price' => 'required',
            'stock' => 'required|integer',
        ]);

        if ($validator->fails())
            return response()->json($validator->errors(), 400);

        Product::create($request->all());

        return response(status: 201);
    }

    public function show(int $id) : JsonResponse | Response
    {
        $product = Product::find($id);

        if(!$product)
            return response(status: 404);

        return response()->json($product);
    }

    public function update(Request $request, int $id) : JsonResponse | Response
    {
        $validator = Validator::make($request->all(), [
            'name' => 'nullable|string',
            'description' => 'nullable|string',
            'price' => 'nullable',
            'stock' => 'nullable|integer',
        ]);

        if ($validator->fails())
            return response()->json($validator->errors(), 400);

        $product = Product::find($id);

        if (!$product) {
            return response(status: 404);
        }

        $product->update($request->all());

        return response()->json([
            'message' => 'Produto atualizado com sucesso',
            'status' => true
        ], 200);

        return response(status: 200);
    }

    public function destroy(int $id) : Response
    {
        $product = Product::find($id);

        if(!$product)
            return response(status: 404);

        $product->delete();

        return response(status: 200);
    }
}

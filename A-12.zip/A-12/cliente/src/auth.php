<?php

$credenciais = [
    'email' => 'teste@teste.com',
    'password' => '123456'
];
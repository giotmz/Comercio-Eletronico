<?php
$usuario = '20201101110026';
$senha = 'ALJ10*#';